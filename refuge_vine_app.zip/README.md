
Refuge — Vine & Oil (Flutter)
=============================

Starterprojekt mit Weinstock (Joh 15) & Öl/Lampe (Mt 25). CI erzeugt das Android App Bundle (AAB) aus der ZIP.

Schnellstart lokal (falls PC vorhanden):
  flutter pub get
  flutter run -d android

Für Smartphone-Nutzer: Folge der beiliegenden PDF-Anleitung.
